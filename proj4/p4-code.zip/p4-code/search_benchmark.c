// Complete this main to benchmark the search algorithms outlined in
// the project specification
int main(int argc, char *argv[]){
  return 0;
}
